import 'package:flutter/material.dart';

class RequestsScreen extends StatelessWidget {
  const RequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "Requests Coming Soon...",
        style: TextStyle(color: Colors.white, fontSize: 18),
      ),
    );
  }
}
